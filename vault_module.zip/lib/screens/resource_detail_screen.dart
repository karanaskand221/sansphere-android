import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import '../global_state.dart';
import '../models/academic_resource.dart';
import 'chat_list_screen.dart';

class ResourceDetailScreen extends StatefulWidget {
  final AcademicResource resource;
  final String? referrerUid;
  const ResourceDetailScreen({super.key, required this.resource, this.referrerUid});

  @override
  State<ResourceDetailScreen> createState() => _ResourceDetailScreenState();
}

class _ResourceDetailScreenState extends State<ResourceDetailScreen> {
  bool _isProcessing = false;

  final _firestore = FirebaseFirestore.instanceFor(app: Firebase.app(), databaseId: 'sansphere');

  bool get _isPurchased =>
      widget.resource.price <= 0 ||
      GlobalState.purchasedResourceTitles.contains(widget.resource.id);

  @override
  void initState() {
    super.initState();
    _creditReferrerIfNeeded();
  }

  Future<void> _creditReferrerIfNeeded() async {
    final viewerUid = FirebaseAuth.instance.currentUser?.uid;
    if (widget.referrerUid == null || viewerUid == null || viewerUid == widget.referrerUid) return;

    final viewKey = "${widget.resource.id}_$viewerUid";
    final viewRef = _firestore.collection('docViews').doc(viewKey);
    final existing = await viewRef.get();
    if (existing.exists) return;

    await viewRef.set({
      'docId': widget.resource.id,
      'viewerUid': viewerUid,
      'referrerUid': widget.referrerUid,
      'createdAt': FieldValue.serverTimestamp(),
    });
    await _firestore.collection('users').doc(widget.referrerUid).update({
      'sanCoins': FieldValue.increment(10),
    });
  }

  Future<void> _handleAccessTap() async {
    if (widget.resource.fileUrl.isEmpty) {
      _showMessage("No file is attached to this resource.", isError: true);
      return;
    }

    if (!_isPurchased) {
      final confirmed = await _confirmPurchase();
      if (confirmed != true) return;

      if (GlobalState.currentUserWallet < widget.resource.price) {
        _showMessage("Insufficient wallet balance.", isError: true);
        return;
      }

      setState(() {
        GlobalState.currentUserWallet -= widget.resource.price;
        GlobalState.creatorEarnings.update(
          widget.resource.authorUid,
          (value) => value + widget.resource.price,
          ifAbsent: () => widget.resource.price,
        );
        GlobalState.purchasedResourceTitles.add(widget.resource.id);
      });
    }

    await _openFile();
  }

  Future<bool?> _confirmPurchase() {
    return showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Unlock Document"),
        content: Text(
          "Access to \"${widget.resource.title}\" costs ₹${widget.resource.price.toStringAsFixed(2)}. Proceed?",
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            child: const Text("Pay & Open"),
          ),
        ],
      ),
    );
  }

  Future<void> _openFile() async {
    setState(() => _isProcessing = true);
    try {
      final uri = Uri.parse(widget.resource.fileUrl);
      final launched = await launchUrl(uri, mode: LaunchMode.externalApplication);
      if (!launched) {
        throw Exception("No app available to open this file.");
      }
    } catch (e) {
      _showMessage("Couldn't open file: $e", isError: true);
    } finally {
      if (mounted) setState(() => _isProcessing = false);
    }
  }

  void _showMessage(String message, {bool isError = false}) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        backgroundColor: isError ? Colors.redAccent : Colors.green,
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final resource = widget.resource;
    return Scaffold(
      backgroundColor: const Color(0xFFF8FAFC),
      appBar: AppBar(
        title: const Text("Resource Details"),
        backgroundColor: Colors.white,
        foregroundColor: Colors.black,
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(24.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: Colors.white,
                borderRadius: BorderRadius.circular(20),
                boxShadow: [
                  BoxShadow(color: Colors.black.withValues(alpha: 0.05), blurRadius: 10, offset: const Offset(0, 4)),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(resource.type.toUpperCase(),
                      style: const TextStyle(color: Color(0xFF2563EB), fontWeight: FontWeight.bold, letterSpacing: 1.2)),
                  const SizedBox(height: 12),
                  Text(resource.title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 8),
                  Text("By ${resource.authorName} • ${resource.college}", style: const TextStyle(color: Colors.grey)),
                  if (resource.fileName.isNotEmpty) ...[
                    const SizedBox(height: 8),
                    Text("${resource.fileName} • ${resource.meta}",
                        style: const TextStyle(color: Colors.grey, fontSize: 13)),
                  ],
                  const Divider(height: 40),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      const Text("Access Price", style: TextStyle(color: Colors.grey)),
                      Text(
                        resource.price <= 0 ? "Free" : "₹${resource.price.toStringAsFixed(2)}",
                        style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.green),
                      ),
                    ],
                  ),
                  if (_isPurchased && resource.price > 0) ...[
                    const SizedBox(height: 8),
                    const Text("✓ Already unlocked", style: TextStyle(color: Colors.green, fontWeight: FontWeight.w600)),
                  ],
                ],
              ),
            ),
            const SizedBox(height: 30),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: ElevatedButton(
                style: ElevatedButton.styleFrom(
                  backgroundColor: const Color(0xFF2563EB),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: _isProcessing ? null : _handleAccessTap,
                child: _isProcessing
                    ? const SizedBox(
                        width: 22,
                        height: 22,
                        child: CircularProgressIndicator(strokeWidth: 2.5, color: Colors.white),
                      )
                    : Text(
                        _isPurchased ? "Open Document" : "Unlock & Open",
                        style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.bold),
                      ),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              height: 54,
              child: OutlinedButton.icon(
                icon: const Icon(Icons.chat_bubble_outline, color: Color(0xFF2563EB)),
                label: const Text("Message Seller", style: TextStyle(color: Color(0xFF2563EB), fontWeight: FontWeight.bold)),
                style: OutlinedButton.styleFrom(
                  side: const BorderSide(color: Color(0xFF2563EB)),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () => startChatWithUser(
                  context,
                  peerUid: resource.authorUid,
                  peerName: resource.authorName,
                  docTitle: resource.title,
                  docId: resource.id,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
