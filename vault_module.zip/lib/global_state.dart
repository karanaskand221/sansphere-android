
/// Central state machine handling isolated state changes 
/// for the localized platform engine.
class GlobalState {
  // Mock ledger assets representing current session user parameters
  static double currentUserWallet = 150.0; // Seed liquidity
  static double platformProcessingPool = 0.0;

  // Trackers monitoring cross-screen user updates
  static final Set<String> purchasedResourceTitles = {};
  static final Map<String, double> creatorEarnings = {};
}